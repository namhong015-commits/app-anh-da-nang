
// Tabs
const btnDocs = document.getElementById('btn-docs');
btnDocs.onclick = () => alert(`Hướng dẫn:
- Text→Image: nhập prompt và Generate
- Image→Image: chọn ảnh + prompt (tuỳ chọn)
- Remove BG / Upscale: chọn ảnh và chạy
Có thể nối API thật bằng cách set biến môi trường:
  PROVIDER_URL, PROVIDER_TOKEN
`);

const panelKeys = ["txt2img","img2img","bgremove","upscale"];
const panels = Object.fromEntries(panelKeys.map(k=>[k, document.getElementById(`panel-${k}`)]));
document.querySelectorAll('[data-tab]').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const k = btn.dataset.tab;
    Object.values(panels).forEach(p=>p.classList.add('hidden'));
    panels[k].classList.remove('hidden');
    document.querySelectorAll('[data-tab]').forEach(b=>b.classList.add('outline'));
    btn.classList.remove('outline');
  });
});

const downloadLink = document.getElementById('download-link');
const metaEl = document.getElementById('meta');

function setOutput(el, dataUrl, meta){
  el.innerHTML = '';
  const img = document.createElement('img');
  img.src = dataUrl; img.alt = 'output'; img.style.maxWidth='100%'; img.style.borderRadius='8px';
  el.appendChild(img);
  downloadLink.href = dataUrl;
  metaEl.textContent = JSON.stringify(meta||{}, null, 2);
}

// Text→Image
document.getElementById('t2i-run').onclick = async ()=>{
  const prompt = document.getElementById('t2i-prompt').value;
  const aspect = document.getElementById('t2i-aspect').value;
  const style = document.getElementById('t2i-style').value;
  const seed = document.getElementById('t2i-seed').value;
  const res = await fetch('/api/images/txt2img', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ prompt, aspect, style, seed }) });
  const data = await res.json();
  setOutput(document.getElementById('out-t2i'), data.imageDataUrl, data.meta);
};

// Image→Image
document.getElementById('i2i-run').onclick = async ()=>{
  const f = document.getElementById('i2i-file').files[0];
  const prompt = document.getElementById('i2i-prompt').value;
  if(!f){ alert('Chọn ảnh trước đã'); return; }
  const fd = new FormData(); fd.append('image', f); fd.append('prompt', prompt);
  const res = await fetch('/api/images/img2img', { method:'POST', body: fd });
  const data = await res.json();
  setOutput(document.getElementById('out-i2i'), data.imageDataUrl, data.meta);
};

// Remove BG
document.getElementById('bg-run').onclick = async ()=>{
  const f = document.getElementById('bg-file').files[0];
  if(!f){ alert('Chọn ảnh trước đã'); return; }
  const fd = new FormData(); fd.append('image', f);
  const res = await fetch('/api/images/bg/remove', { method:'POST', body: fd });
  const data = await res.json();
  setOutput(document.getElementById('out-bg'), data.imageDataUrl, { action:"bg_remove" });
};

// Upscale
document.getElementById('up-run').onclick = async ()=>{
  const f = document.getElementById('up-file').files[0];
  if(!f){ alert('Chọn ảnh trước đã'); return; }
  const fd = new FormData(); fd.append('image', f);
  const res = await fetch('/api/images/upscale', { method:'POST', body: fd });
  const data = await res.json();
  setOutput(document.getElementById('out-up'), data.imageDataUrl, { action:"upscale_x2" });
};
