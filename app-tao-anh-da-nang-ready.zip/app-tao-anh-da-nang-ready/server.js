
/* APP TẠO ẢNH ĐA NĂNG – Ready (single folder)
 * Run: node server.js
 * Open: http://localhost:3000
 * Optional provider forwarding: set env PROVIDER_URL + PROVIDER_TOKEN to relay prompts to your own generator API.
 */
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import multer from "multer";
import fetch from "node-fetch";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const upload = multer({ storage: multer.memoryStorage() });

app.use(express.json({ limit: "15mb" }));
app.use(express.urlencoded({ extended: true }));

const PROVIDER_URL = process.env.PROVIDER_URL || "";
const PROVIDER_TOKEN = process.env.PROVIDER_TOKEN || "";

function svgDataUrl({ title = "Image", subtitle = "", w = 1024, h = 1024, seed = "" }) {
  const grad = ["#1f2937","#0f172a","#111827","#0b1220"][Math.floor(Math.random()*4)];
  const svg = `<?xml version="1.0" encoding="UTF-8"?>
  <svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="${grad}" />
        <stop offset="1" stop-color="#4f46e5" />
      </linearGradient>
    </defs>
    <rect width="100%" height="100%" fill="url(#g)"/>
    <g fill="#fff" font-family="ui-sans-serif, system-ui">
      <text x="50%" y="45%" dominant-baseline="middle" text-anchor="middle" font-size="${Math.max(24, Math.min(48, w/20))}" font-weight="700">${title.replace(/&/g,"&amp;")}</text>
      <text x="50%" y="56%" dominant-baseline="middle" text-anchor="middle" font-size="${Math.max(14, Math.min(24, w/40))}" opacity="0.85">${subtitle.replace(/&/g,"&amp;")}</text>
      <text x="50%" y="${h-24}" dominant-baseline="middle" text-anchor="middle" font-size="12" opacity="0.6">offline mock • ${new Date().toISOString().slice(0,10)} ${seed?"• "+seed:""}</text>
    </g>
  </svg>`;
  const b64 = Buffer.from(svg).toString("base64");
  return `data:image/svg+xml;base64,${b64}`;
}

async function relayToProvider(endpoint, payload) {
  if (!PROVIDER_URL) return null;
  try {
    const url = `${PROVIDER_URL}${endpoint}`;
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(PROVIDER_TOKEN ? { "Authorization": `Bearer ${PROVIDER_TOKEN}` } : {}),
      },
      body: JSON.stringify(payload || {})
    });
    if (!res.ok) throw new Error(`Provider ${res.status}`);
    const data = await res.json();
    // Expect provider to return { imageDataUrl } or { images: [dataUrl] } – normalize:
    const out = data.imageDataUrl || (Array.isArray(data.images) && data.images[0]) || null;
    return out;
  } catch (e) {
    console.error("Provider error:", e.message);
    return null;
  }
}

// Health
app.get("/api/health", (_req, res) => res.json({ ok: true, service: "APP TẠO ẢNH ĐA NĂNG", version: "1.0.0" }));

// Text→Image
app.post("/api/images/txt2img", async (req, res) => {
  const { prompt = "Hình minh hoạ", aspect = "1:1", style = "default", seed = "" } = req.body || {};
  let dataUrl = await relayToProvider("/txt2img", { prompt, aspect, style, seed });
  if (!dataUrl) {
    const subtitle = `${aspect} • ${style}`;
    dataUrl = svgDataUrl({ title: prompt.slice(0,60), subtitle, seed });
  }
  res.json({ imageDataUrl: dataUrl, meta: { prompt, aspect, style, seed, source: PROVIDER_URL ? "provider" : "offline-mock" } });
});

// Image→Image (variation / edit)
app.post("/api/images/img2img", upload.single("image"), async (req, res) => {
  const prompt = (req.body?.prompt || "Biến thể hình ảnh");
  let dataUrl = await relayToProvider("/img2img", { prompt, image: req.file?.buffer?.toString("base64") });
  if (!dataUrl) {
    dataUrl = svgDataUrl({ title: "Variation", subtitle: prompt.slice(0,60) });
  }
  res.json({ imageDataUrl: dataUrl, meta: { prompt, source: PROVIDER_URL ? "provider" : "offline-mock" } });
});

// Background removal (mock)
app.post("/api/images/bg/remove", upload.single("image"), async (_req, res) => {
  const dataUrl = svgDataUrl({ title: "BG Removed", subtitle: "Transparent PNG (mock)" });
  res.json({ imageDataUrl: dataUrl });
});

// Upscale (mock)
app.post("/api/images/upscale", upload.single("image"), async (_req, res) => {
  const dataUrl = svgDataUrl({ title: "Upscaled x2", subtitle: "Enhancement (mock)" });
  res.json({ imageDataUrl: dataUrl });
});

// Serve static UI
import { createRequire } from "module"; const require = createRequire(import.meta.url);
const __public = path.join(__dirname, "public");
app.use(express.static(__public));
app.get("*", (_req, res) => res.sendFile(path.join(__public, "index.html")));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Ready at http://localhost:${PORT}`));
