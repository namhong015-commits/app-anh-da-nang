# APP TẠO ẢNH ĐA NĂNG – Ready (Single-folder)
Chạy ngay, không cần build tools. Có thể dùng offline (mock) hoặc nối API generator thật.

## Yêu cầu
- Node.js 18+

## Chạy
```bash
npm install
npm start
# Mở http://localhost:3000
```

## Nối API generator thật (tuỳ chọn)
Thiết lập biến môi trường:
```
PROVIDER_URL=https://your-generator.example.com
PROVIDER_TOKEN=xxxxx
```
App sẽ forward gọi:
- POST ${PROVIDER_URL}/txt2img { prompt, aspect, style, seed }
- POST ${PROVIDER_URL}/img2img { prompt, image(base64) }

Provider cần trả về `{ imageDataUrl }` hoặc `{ images: [dataUrl] }`.
